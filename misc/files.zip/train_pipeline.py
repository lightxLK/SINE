"""
src/train_pipeline.py
Master script — runs the full training pipeline end-to-end.

Usage:
    python src/train_pipeline.py --csv data/Dataset-SA.csv --mode all
    python src/train_pipeline.py --csv data/Dataset-SA.csv --mode classical
    python src/train_pipeline.py --csv data/Dataset-SA.csv --mode bert
"""

import argparse
import os
import pandas as pd
from sklearn.model_selection import train_test_split

from preprocessing       import validate_and_preprocess
from feature_engineering import build_tfidf, build_bert_datasets, encode_labels
from models              import (
    apply_smote,
    train_logistic_regression,
    train_random_forest,
    train_xgboost,
    train_bert,
)
from evaluation import (
    evaluate_model,
    plot_confusion_matrix,
    neutral_class_analysis,
    compare_models,
)


def ensure_dirs():
    for d in ["models", "reports"]:
        os.makedirs(d, exist_ok=True)


def run_classical(df: pd.DataFrame, le):
    """TF-IDF → LR / RF / XGBoost."""
    X_train_t, X_val_t, y_train, y_val = train_test_split(
        df["clean_text"],
        df["label_encoded"],
        test_size=0.2,
        stratify=df["label_encoded"],
        random_state=42,
    )

    X_train_tfidf, X_val_tfidf, _ = build_tfidf(
        list(X_train_t), list(X_val_t)
    )

    # SMOTE on TF-IDF sparse matrix
    X_sm, y_sm = apply_smote(X_train_tfidf, y_train)

    results = []

    # ── Logistic Regression ────────────────────────────────────────────────
    lr_model  = train_logistic_regression(X_sm, y_sm)
    lr_preds  = lr_model.predict(X_val_tfidf)
    results.append(evaluate_model(y_val, lr_preds, le, "Logistic Regression"))
    plot_confusion_matrix(y_val, lr_preds, le, "LR", "reports/cm_lr.png")
    neutral_class_analysis(y_val, lr_preds, le)

    # ── Random Forest ─────────────────────────────────────────────────────
    rf_model  = train_random_forest(X_sm, y_sm)
    rf_preds  = rf_model.predict(X_val_tfidf)
    results.append(evaluate_model(y_val, rf_preds, le, "Random Forest"))
    plot_confusion_matrix(y_val, rf_preds, le, "RF", "reports/cm_rf.png")
    neutral_class_analysis(y_val, rf_preds, le)

    # ── XGBoost ───────────────────────────────────────────────────────────
    xgb_model = train_xgboost(X_sm, y_sm, n_classes=len(le.classes_))
    xgb_preds = xgb_model.predict(X_val_tfidf)
    results.append(evaluate_model(y_val, xgb_preds, le, "XGBoost"))
    plot_confusion_matrix(y_val, xgb_preds, le, "XGBoost", "reports/cm_xgb.png")
    neutral_class_analysis(y_val, xgb_preds, le)

    compare_models(results)
    return results


def run_bert(df: pd.DataFrame, le):
    """BERT fine-tuning."""
    X_train_t, X_val_t, y_train, y_val = train_test_split(
        df["clean_text"],
        df["label_encoded"],
        test_size=0.2,
        stratify=df["label_encoded"],
        random_state=42,
    )

    train_ds, val_ds, tokenizer = build_bert_datasets(
        list(X_train_t), list(X_val_t),
        y_train.values, y_val.values,
    )

    model, trainer = train_bert(
        train_ds, val_ds,
        n_labels=len(le.classes_),
    )

    # Evaluate BERT
    preds_out = trainer.predict(val_ds)
    preds     = preds_out.predictions.argmax(axis=1)
    result    = evaluate_model(y_val.values, preds, le, "BERT")
    plot_confusion_matrix(y_val.values, preds, le, "BERT", "reports/cm_bert.png")
    neutral_class_analysis(y_val.values, preds, le)
    return [result]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv",  default="data/Dataset-SA.csv")
    parser.add_argument("--mode", choices=["classical", "bert", "all"], default="classical")
    args = parser.parse_args()

    ensure_dirs()

    print(f"\n{'='*55}")
    print("  Agentic Sentiment Intelligence System — Training")
    print(f"{'='*55}\n")

    # ── Load + preprocess ─────────────────────────────────────────────────
    raw_df = pd.read_csv(args.csv)
    df     = validate_and_preprocess(raw_df)

    # ── Label encoding ────────────────────────────────────────────────────
    df["label_encoded"], le = encode_labels(df["Label"])

    # ── Run chosen mode ───────────────────────────────────────────────────
    all_results = []

    if args.mode in ("classical", "all"):
        all_results += run_classical(df, le)

    if args.mode in ("bert", "all"):
        all_results += run_bert(df, le)

    if len(all_results) > 1:
        print("\n\n Final Leaderboard:")
        compare_models(all_results)

    print("\n[Pipeline] Complete. Models saved to ./models/")


if __name__ == "__main__":
    main()
