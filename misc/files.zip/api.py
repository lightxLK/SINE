"""
app/api.py
FastAPI inference server — serves predictions from saved models.

Run:
    uvicorn app.api:app --reload --port 8000
"""

import os
import joblib
import torch
import numpy as np
from fastapi           import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic          import BaseModel
from transformers      import BertForSequenceClassification, BertTokenizer

# ─────────────────────────────────────────────────────────────────────────────
#  App setup
# ─────────────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="Sentiment Analysis API",
    description="Agentic Sentiment Intelligence — 8th Semester 2026",
    version="2.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─────────────────────────────────────────────────────────────────────────────
#  Load models at startup
# ─────────────────────────────────────────────────────────────────────────────

MODELS_DIR = os.environ.get("MODELS_DIR", "models")
LABEL_MAP  = {0: "negative", 1: "neutral", 2: "positive"}   # default LabelEncoder order

_tfidf      = None
_xgb_model  = None
_bert_model = None
_bert_tok   = None
_le         = None


@app.on_event("startup")
def load_models():
    global _tfidf, _xgb_model, _bert_model, _bert_tok, _le

    tfidf_path = os.path.join(MODELS_DIR, "tfidf_vectorizer.pkl")
    xgb_path   = os.path.join(MODELS_DIR, "xgb.pkl")
    bert_path  = os.path.join(MODELS_DIR, "bert_model")
    le_path    = os.path.join(MODELS_DIR, "label_encoder.pkl")

    if os.path.exists(tfidf_path):
        _tfidf = joblib.load(tfidf_path)
        print("[API] TF-IDF loaded")

    if os.path.exists(xgb_path):
        _xgb_model = joblib.load(xgb_path)
        print("[API] XGBoost loaded")

    if os.path.exists(bert_path):
        _bert_model = BertForSequenceClassification.from_pretrained(bert_path)
        _bert_tok   = BertTokenizer.from_pretrained(bert_path)
        _bert_model.eval()
        print("[API] BERT loaded")

    if os.path.exists(le_path):
        _le = joblib.load(le_path)
        print("[API] LabelEncoder loaded")


# ─────────────────────────────────────────────────────────────────────────────
#  Preprocessing (inline — mirrors src/preprocessing.py)
# ─────────────────────────────────────────────────────────────────────────────

import re, string, nltk, emoji
from nltk.corpus import stopwords
from nltk.stem   import WordNetLemmatizer

for pkg in ["stopwords", "wordnet", "omw-1.4"]:
    nltk.download(pkg, quiet=True)

_sw   = set(stopwords.words("english"))
_lemm = WordNetLemmatizer()

def _clean(text: str) -> str:
    text = text.lower()
    text = re.sub(r"http\S+|www\S+", " ", text)
    text = re.sub(r"<.*?>", " ", text)
    text = emoji.demojize(text, delimiters=(" ", " "))
    text = text.translate(str.maketrans("", "", string.punctuation))
    text = re.sub(r"\d+", " ", text)
    tokens = [_lemm.lemmatize(t) for t in text.split() if t not in _sw and len(t) > 2]
    return " ".join(tokens)


# ─────────────────────────────────────────────────────────────────────────────
#  Schema
# ─────────────────────────────────────────────────────────────────────────────

class ReviewRequest(BaseModel):
    text: str
    model: str = "bert"   # "bert" | "xgboost" | "lr"


class PredictionResponse(BaseModel):
    sentiment:   str
    confidence:  float
    model_used:  str
    clean_text:  str


# ─────────────────────────────────────────────────────────────────────────────
#  Endpoints
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/")
def root():
    return {"status": "Sentiment API running", "version": "2.0"}


@app.get("/health")
def health():
    return {
        "tfidf_loaded": _tfidf is not None,
        "xgb_loaded":   _xgb_model is not None,
        "bert_loaded":  _bert_model is not None,
    }


@app.post("/predict", response_model=PredictionResponse)
def predict(req: ReviewRequest):
    cleaned = _clean(req.text)

    # ── BERT ──────────────────────────────────────────────────────────────
    if req.model == "bert":
        if _bert_model is None or _bert_tok is None:
            raise HTTPException(503, "BERT model not loaded")

        inputs  = _bert_tok(cleaned, return_tensors="pt", truncation=True,
                            padding=True, max_length=128)
        with torch.no_grad():
            logits  = _bert_model(**inputs).logits
        probs   = torch.softmax(logits, dim=-1).squeeze().numpy()
        pred    = int(np.argmax(probs))
        conf    = float(probs[pred])

    # ── XGBoost ───────────────────────────────────────────────────────────
    elif req.model in ("xgboost", "lr"):
        model_obj = _xgb_model if req.model == "xgboost" else None
        if model_obj is None:
            raise HTTPException(503, f"{req.model} model not loaded")
        if _tfidf is None:
            raise HTTPException(503, "TF-IDF vectorizer not loaded")

        vec   = _tfidf.transform([cleaned])
        probs = model_obj.predict_proba(vec)[0]
        pred  = int(np.argmax(probs))
        conf  = float(probs[pred])

    else:
        raise HTTPException(400, f"Unknown model: {req.model}")

    # ── Decode label ──────────────────────────────────────────────────────
    if _le is not None:
        label = str(_le.inverse_transform([pred])[0])
    else:
        label = LABEL_MAP.get(pred, str(pred))

    return PredictionResponse(
        sentiment=label,
        confidence=round(conf, 4),
        model_used=req.model,
        clean_text=cleaned,
    )
