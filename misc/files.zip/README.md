# 🧠 Agentic Sentiment Intelligence System
**Capstone Project — 8th Semester 2026**
Sentiment Analysis of Online Product Reviews (Amazon · Flipkart · Myntra)

---

## Project Structure

```
sentiment_ai/
├── data/
│   └── Dataset-SA.csv          ← your dataset goes here
│
├── src/
│   ├── preprocessing.py        ← Data Refinery Agent
│   ├── feature_engineering.py  ← TF-IDF + BERT tokenisation
│   ├── models.py               ← LR / RF / XGBoost / BERT training
│   ├── evaluation.py           ← Critic Agent (metrics, plots, SHAP)
│   └── train_pipeline.py       ← Master runner
│
├── app/
│   ├── api.py                  ← FastAPI backend
│   └── streamlit_app.py        ← Streamlit UI
│
├── notebooks/
│   └── eda.py                  ← EDA script (run first)
│
├── models/                     ← saved models land here
├── reports/                    ← confusion matrices, charts
└── requirements.txt
```

---

## Setup

```bash
# 1. Create virtual environment
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Download spaCy model (optional, for advanced NLP)
python -m spacy download en_core_web_sm

# 4. Put your dataset in place
mkdir -p data
cp /path/to/Dataset-SA.csv data/
```

---

## Run Order

### Step 1 — EDA (always do this first)
```bash
python notebooks/eda.py --csv data/Dataset-SA.csv
```
Generates class distribution, text length plots, and WordClouds in `reports/`.

### Step 2 — Train classical models (fast, ~2 min)
```bash
python src/train_pipeline.py --csv data/Dataset-SA.csv --mode classical
```
Trains Logistic Regression, Random Forest, XGBoost with TF-IDF + SMOTE.

### Step 3 — Train BERT (slower, GPU recommended)
```bash
python src/train_pipeline.py --csv data/Dataset-SA.csv --mode bert
```
Fine-tunes `bert-base-uncased`. Expects 4 epochs.

### Step 4 — Train everything
```bash
python src/train_pipeline.py --csv data/Dataset-SA.csv --mode all
```

### Step 5 — Start the API
```bash
uvicorn app.api:app --reload --port 8000
```
Check health: http://localhost:8000/health

### Step 6 — Start the Streamlit UI
```bash
streamlit run app/streamlit_app.py
```
Opens at http://localhost:8501

---

## API Usage

```bash
# Single prediction
curl -X POST http://localhost:8000/predict \
     -H "Content-Type: application/json" \
     -d '{"text": "Amazing product! Very happy with the quality.", "model": "bert"}'

# Response
{
  "sentiment": "positive",
  "confidence": 0.9821,
  "model_used": "bert",
  "clean_text": "amazing product happy quality"
}
```

---

## Accuracy Targets

| Model             | Feature    | Expected Accuracy |
|-------------------|------------|-------------------|
| Logistic Regression | TF-IDF   | 78–85%            |
| Random Forest     | TF-IDF     | 80–87%            |
| XGBoost           | TF-IDF     | 82–88%            |
| **BERT**          | Embeddings | **90–95%+**       |

> BERT is the primary model for hitting 95%+.
> Classical models are used for fast benchmarking and model comparison.

---

## Key Design Decisions

- **SMOTE** balances the Neutral class (always underrepresented)
- **Early stopping** in BERT prevents overfitting on 1000-row dataset
- **SHAP** explainability on XGBoost for capstone presentation visuals
- **FastAPI** separates inference from UI — production-ready pattern
- **Streamlit** tabs: single predict → batch CSV → EDA dashboard

---

## Dataset Columns

| Column    | Description                        |
|-----------|------------------------------------|
| Text      | Raw review content                 |
| Label     | Positive / Neutral / Negative      |
| Window    | Platform (Amazon / Flipkart / Myntra) |
| User Name | Reviewer name (simulated)          |
| User ID   | Unique reviewer ID                 |
