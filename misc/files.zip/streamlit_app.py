"""
app/streamlit_app.py
Streamlit frontend — interactive sentiment analysis UI.

Run:
    streamlit run app/streamlit_app.py
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import streamlit as st
import pandas    as pd
import plotly.express as px
import requests
from wordcloud import WordCloud
import matplotlib.pyplot as plt

# ─────────────────────────────────────────────────────────────────────────────
#  Page config
# ─────────────────────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="Sentiment Intelligence",
    page_icon="🧠",
    layout="wide",
)

API_URL = os.environ.get("API_URL", "http://localhost:8000")

SENTIMENT_COLORS = {
    "positive": "#22c55e",
    "neutral":  "#facc15",
    "negative": "#ef4444",
}

# ─────────────────────────────────────────────────────────────────────────────
#  Sidebar
# ─────────────────────────────────────────────────────────────────────────────

with st.sidebar:
    st.title("⚙️ Settings")
    model_choice = st.selectbox("Model", ["bert", "xgboost", "lr"])
    st.markdown("---")
    st.markdown("**Dataset path**")
    data_file = st.text_input("CSV path", value="data/Dataset-SA.csv")
    st.markdown("---")
    st.caption("Capstone — 8th Semester 2026")

# ─────────────────────────────────────────────────────────────────────────────
#  Header
# ─────────────────────────────────────────────────────────────────────────────

st.title("🧠 Agentic Sentiment Intelligence")
st.markdown(
    "Classify product reviews from **Amazon · Flipkart · Myntra** into "
    "**Positive / Neutral / Negative** sentiment."
)
st.divider()

# ─────────────────────────────────────────────────────────────────────────────
#  Tab layout
# ─────────────────────────────────────────────────────────────────────────────

tab_predict, tab_batch, tab_eda = st.tabs(["🔍 Predict", "📋 Batch", "📊 EDA"])


# ────────────────────────────────────────────────────────────────────────────
#  TAB 1 — Single Prediction
# ─────────────────────────────────────────────────────────────────────────────

with tab_predict:
    st.subheader("Single Review Prediction")
    review_text = st.text_area(
        "Paste a product review here",
        height=140,
        placeholder="e.g. The product quality is great but delivery was late...",
    )

    if st.button("Analyse Sentiment", type="primary"):
        if not review_text.strip():
            st.warning("Please enter a review.")
        else:
            with st.spinner("Calling model..."):
                try:
                    resp = requests.post(
                        f"{API_URL}/predict",
                        json={"text": review_text, "model": model_choice},
                        timeout=30,
                    )
                    resp.raise_for_status()
                    data = resp.json()

                    sentiment  = data["sentiment"]
                    confidence = data["confidence"]
                    color      = SENTIMENT_COLORS.get(sentiment, "#64748b")

                    col1, col2, col3 = st.columns(3)
                    col1.metric("Sentiment",   sentiment.upper())
                    col2.metric("Confidence",  f"{confidence*100:.1f}%")
                    col3.metric("Model",       data["model_used"].upper())

                    st.markdown(
                        f"<div style='background:{color}22; border-left:4px solid {color};"
                        f"padding:12px 16px; border-radius:6px; margin-top:12px;'>"
                        f"<b style='color:{color}'>► {sentiment.capitalize()}</b> — "
                        f"confidence {confidence*100:.1f}%</div>",
                        unsafe_allow_html=True,
                    )

                    with st.expander("Cleaned text (what the model saw)"):
                        st.code(data["clean_text"])

                except requests.exceptions.ConnectionError:
                    st.error(
                        "Cannot reach API. Make sure it's running:\n\n"
                        "```\nuvicorn app.api:app --reload --port 8000\n```"
                    )
                except Exception as e:
                    st.error(f"Error: {e}")


# ─────────────────────────────────────────────────────────────────────────────
#  TAB 2 — Batch Prediction
# ─────────────────────────────────────────────────────────────────────────────

with tab_batch:
    st.subheader("Batch CSV Prediction")
    uploaded = st.file_uploader("Upload a CSV with a 'Text' column", type=["csv"])

    if uploaded and st.button("Run Batch", type="primary"):
        df_up = pd.read_csv(uploaded)
        if "Text" not in df_up.columns:
            st.error("CSV must have a 'Text' column.")
        else:
            results = []
            progress = st.progress(0)
            for i, row in df_up.iterrows():
                try:
                    r = requests.post(
                        f"{API_URL}/predict",
                        json={"text": str(row["Text"]), "model": model_choice},
                        timeout=30,
                    ).json()
                    results.append({
                        "Text":       row["Text"],
                        "Sentiment":  r.get("sentiment"),
                        "Confidence": r.get("confidence"),
                    })
                except Exception:
                    results.append({"Text": row["Text"], "Sentiment": "error", "Confidence": 0})
                progress.progress((i + 1) / len(df_up))

            out_df = pd.DataFrame(results)
            st.dataframe(out_df, use_container_width=True)

            # Distribution chart
            fig = px.pie(
                out_df, names="Sentiment",
                color="Sentiment",
                color_discrete_map=SENTIMENT_COLORS,
                title="Predicted Sentiment Distribution",
            )
            st.plotly_chart(fig, use_container_width=True)

            csv_out = out_df.to_csv(index=False).encode("utf-8")
            st.download_button("⬇ Download Results", csv_out, "predictions.csv", "text/csv")


# ─────────────────────────────────────────────────────────────────────────────
#  TAB 3 — EDA
# ─────────────────────────────────────────────────────────────────────────────

with tab_eda:
    st.subheader("Exploratory Data Analysis")

    if os.path.exists(data_file):
        df = pd.read_csv(data_file)

        col1, col2, col3 = st.columns(3)
        col1.metric("Total Reviews", len(df))
        col2.metric("Platforms",     df["Window"].nunique() if "Window" in df.columns else "—")
        col3.metric("Classes",       df["Label"].nunique()  if "Label"  in df.columns else "—")

        st.markdown("#### Class Distribution")
        if "Label" in df.columns:
            label_counts = df["Label"].value_counts().reset_index()
            label_counts.columns = ["Sentiment", "Count"]
            fig = px.bar(
                label_counts, x="Sentiment", y="Count",
                color="Sentiment",
                color_discrete_map=SENTIMENT_COLORS,
            )
            st.plotly_chart(fig, use_container_width=True)

        if "Window" in df.columns:
            st.markdown("#### Reviews per Platform")
            fig2 = px.pie(df, names="Window", title="Platform Distribution")
            st.plotly_chart(fig2, use_container_width=True)

        st.markdown("#### WordCloud")
        if "Text" in df.columns:
            all_text = " ".join(df["Text"].astype(str).tolist())
            from wordcloud import STOPWORDS as WC_SW
            custom_sw = set(WC_SW) | {"product", "amazon", "flipkart", "myntra"}
            wc = WordCloud(
                stopwords=custom_sw,
                background_color="white",
                width=1200, height=500,
                colormap="viridis",
            ).generate(all_text)

            fig_wc, ax = plt.subplots(figsize=(12, 5))
            ax.imshow(wc, interpolation="bilinear")
            ax.axis("off")
            st.pyplot(fig_wc)

    else:
        st.info(f"Dataset not found at `{data_file}`. Adjust the path in the sidebar.")
