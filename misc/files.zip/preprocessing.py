"""
src/preprocessing.py
Data Refinery Agent — cleans and validates raw review data.
"""

import re
import string
import pandas as pd
import nltk
import emoji
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

# ── one-time downloads (safe to re-run) ──────────────────────────────────────
for pkg in ["stopwords", "wordnet", "omw-1.4", "punkt"]:
    nltk.download(pkg, quiet=True)

STOPWORDS   = set(stopwords.words("english"))
lemmatizer  = WordNetLemmatizer()

# basic slang map — extend this with your own domain knowledge
SLANG_MAP = {
    "gr8": "great", "luv": "love", "pls": "please", "plz": "please",
    "bcoz": "because", "coz": "because", "u": "you", "r": "are",
    "cn": "can", "wud": "would", "shud": "should", "gud": "good",
    "brt": "bright", "msg": "message", "thx": "thanks", "ty": "thanks",
    "lol": "", "omg": "", "wtf": "",
}


# ─────────────────────────────────────────────────────────────────────────────
#  Text cleaning
# ─────────────────────────────────────────────────────────────────────────────

def clean_text(text: str) -> str:
    """Full NLP cleaning pipeline for a single review string."""
    if pd.isnull(text):
        return ""

    text = str(text).lower()

    # URLs
    text = re.sub(r"http\S+|www\S+|https\S+", " ", text)

    # HTML tags
    text = re.sub(r"<.*?>", " ", text)

    # Emojis → text label (e.g. 😊 → :smiling_face:)
    text = emoji.demojize(text, delimiters=(" ", " "))

    # Punctuation & special chars
    text = text.translate(str.maketrans("", "", string.punctuation))

    # Numbers
    text = re.sub(r"\d+", " ", text)

    # Slang normalisation
    tokens = text.split()
    tokens = [SLANG_MAP.get(tok, tok) for tok in tokens]

    # Stopwords + lemmatisation (keep tokens > 2 chars)
    tokens = [
        lemmatizer.lemmatize(tok)
        for tok in tokens
        if tok not in STOPWORDS and len(tok) > 2
    ]

    return " ".join(tokens)


# ─────────────────────────────────────────────────────────────────────────────
#  DataFrame-level validation + preprocessing
# ─────────────────────────────────────────────────────────────────────────────

LABEL_MAP = {
    "positive": "positive",
    "pos":      "positive",
    "negative": "negative",
    "neg":      "negative",
    "neutral":  "neutral",
    "neu":      "neutral",
}


def validate_and_preprocess(df: pd.DataFrame, verbose: bool = True) -> pd.DataFrame:
    """
    Full validation + preprocessing pipeline.

    Steps
    -----
    1. Strip column whitespace
    2. Drop nulls in Text / Label
    3. Remove duplicate reviews
    4. Normalise label strings
    5. Filter unknown labels
    6. Apply clean_text()
    7. Drop empty cleaned rows
    """
    df = df.copy()
    df.columns = [c.strip() for c in df.columns]

    initial = len(df)

    # 1. Drop null text / label
    df.dropna(subset=["Text", "Label"], inplace=True)

    # 2. Remove duplicates
    df.drop_duplicates(subset=["Text"], inplace=True)

    # 3. Normalise labels
    df["Label"] = df["Label"].str.strip().str.lower().map(LABEL_MAP)

    # 4. Drop unmapped labels
    df.dropna(subset=["Label"], inplace=True)

    # 5. Text length filter (< 3 words → useless)
    df = df[df["Text"].apply(lambda x: len(str(x).split()) >= 3)]

    # 6. Clean
    df["clean_text"] = df["Text"].apply(clean_text)

    # 7. Drop empty cleaned rows
    df = df[df["clean_text"].str.strip().astype(bool)]
    df.reset_index(drop=True, inplace=True)

    if verbose:
        print(f"[Preprocessing] {initial} → {len(df)} rows kept")
        print(f"[Preprocessing] Class distribution:\n{df['Label'].value_counts()}\n")

    return df


# ─────────────────────────────────────────────────────────────────────────────
#  Quick-run for testing
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys, os
    csv_path = sys.argv[1] if len(sys.argv) > 1 else "data/Dataset-SA.csv"

    if not os.path.exists(csv_path):
        print(f"[ERROR] File not found: {csv_path}")
        sys.exit(1)

    raw_df = pd.read_csv(csv_path)
    clean_df = validate_and_preprocess(raw_df)
    clean_df.to_csv("data/clean_dataset.csv", index=False)
    print("[Done] Saved → data/clean_dataset.csv")
    print(clean_df[["Text", "clean_text", "Label"]].head(5))
